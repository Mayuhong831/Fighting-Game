O projeto Folclore Fighter trata-se de um jogo de luta multiplayer com estética retrô e criação
de personagens baseados no folclore brasileiro. O jogo será elaborado para um público alvo com
jogadores amadores e profissionais com idades entre 14 e 36 anos. Tratando-se de um jogo de luta, 
Folclore Fighter trará as mecânicas básicas de jogabilidade para este tipo de modalidade, além de 
uma interação usuário-usuário e efeitos audiovisuais, oferecendo uma clássica e boa experiência aos 
seus jogadores.

O objetivo de todo jogo é promover entretenimento, contudo, tendo em vista uma maior valorização 
de personagens do folclore internacional e a anulação e esquecimento de personagens que fazem 
parte da cultura brasileira, Folclore Fighter tem como principal objetivo despertar o interesse do 
público jovem pelas lendas nacionais, trazendo uma abordagem prática para a inclusão da cultura 
brasileira nesse mercado de jogos.
